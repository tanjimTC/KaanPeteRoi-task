# KaanPeteRoi-task

### You need to have [node] installed on your system to run this project.

### To run the code, You need to clone or download this repo on your computer.

### After you donwloaded or cloned, Open the folder in your favourite code editor and run the command "npm install" to install all the dependencies needed for this project.

### After installing the dependencies run the commad "node app.js" to run the code and see the output!

## List of dependencies/npm packages used for this task :-

- 1 👉 [CSVTOJSON] -to convert csv to json or column arrays.
- 2 👉 [csv-writer] -to convert objects/arrays into a CSV string or write them into a file.

[csvtojson]: https://www.npmjs.com/package/csvtojson
[csv-writer]: https://www.npmjs.com/package/csv-writer
[node]: https://nodejs.org/en/
